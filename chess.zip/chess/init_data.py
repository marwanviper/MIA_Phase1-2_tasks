# Define the piece types with their indices
piece_index = {
    "wp": 0,
    "wn": 1,
    "wr": 2,
    "wq": 3,
    "wb": 4,
    "wk": 5,
    "bp": 6,
    "bn": 7,
    "br": 8,
    "bq": 9,
    "bb": 10,
    "bk": 11,
}

# Initial positions of pieces on the board (8x8 grid)
initial_board = [
    ["wr", "wn", "wb", "wk", "wq", "wb", "wn", "wr"],
    ["wp", "wp", "wp", "wp", "wp", "wp", "wp", "wp"],
    ["", "", "", "", "", "", "", ""],
    ["", "", "", "", "", "", "", ""],
    ["", "", "", "", "", "", "", ""],
    ["", "", "", "", "", "", "", ""],
    ["bp", "bp", "bp", "bp", "bp", "bp", "bp", "bp"],
    ["br", "bn", "bb", "bk", "bq", "bb", "bn", "br"],
]

# Map chessboard positions to indices
letters = "abcdefgh"
numbers = "12345678"
square_size = 100

# Moves dictionary and clickable areas list
moves = {}
clickable_areas = []

for i, letter in enumerate(letters):
    for j, number in enumerate(numbers):
        position = f"{letter}{number}"
        moves[position] = (i, 8 - int(number))  # Algebraic notation to matrix index
        clickable_areas.append(
            (
                (
                    i * square_size,
                    (8 - int(number)) * square_size,
                    (i + 1) * square_size,
                    (8 - int(number) + 1) * square_size,
                ),
                position,
            )
        )
