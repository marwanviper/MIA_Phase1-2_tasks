import pygame
import time

# from wow import moves, clickable_areas
from init_data import (
    moves,
    clickable_areas,
    piece_index as pi,
    initial_board as init_place,
)

pygame.init()
pygame.mixer.init()

"""
Chess game v0.0
Creator: Marwan Abbas
Date: 29-7-2024
"""


class Piece:
    def move(self, origin, destination):
        pass

    @staticmethod
    def move_manager(piece_type, origin, destination):
        global turn
        piece_classes = {
            "wp": Pawn,
            "bp": Pawn,
            "wn": Knight,
            "bn": Knight,
            "wr": Rook,
            "br": Rook,
            "wk": King,
            "bk": King,
            "wb": bishop,
            "bb": bishop,
            "wq": Queen,
            "bq": Queen,
        }
        piece_class = piece_classes.get(piece_type)
        if piece_class and piece_type in list(pi.keys())[:6] and not turn:
            turn = 1
            piece_class(*moves[origin]).move(*moves[destination])
            print("white")
        elif piece_class and piece_type in list(pi.keys())[6:] and turn:
            turn = 0
            piece_class(*moves[origin]).move(*moves[destination])
            print("black")
        else:
            pygame.mixer.Sound.play(errorSound)

    @staticmethod
    def set_position(self, x, y):
        if init_place[y][x] == "":
            pygame.mixer.Sound.play(moveSound)
        else:
            pygame.mixer.Sound.play(captureSound)
        init_place[y][x] = init_place[self.y][self.x]
        init_place[self.y][self.x] = ""
        self.x = x
        self.y = y

    @staticmethod
    def ifEat(self, x, y):
        if init_place[self.y][self.x][0] == "w":
            return init_place[y][x] in list(pi.keys())[6:11]
        elif init_place[self.y][self.x][0] == "b":
            return init_place[y][x] in list(pi.keys())[:5]

    def ismove(self, x, y):
        pass


class Pawn(Piece):
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def move(self, x, y):
        global turn
        if init_place[y][x] == "" and x == self.x and abs(y - self.y) == 1:
            Piece.set_position(self, x, y)
        elif Piece.ifEat(self, x, y) and (abs(x - self.x) == 1 and y - self.y == 1):
            Piece.set_position(self, x, y)
        elif Piece.ifEat(self, x, y) and (abs(x - self.x) == 1 and self.y - y == 1):
            Piece.set_position(self, x, y)
        else:
            pygame.mixer.Sound.play(errorSound)
            turn = not turn


class King(Piece):
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def move(self, x, y):
        global turn
        if init_place[y][x] == "" and max(abs(self.x - x), abs(self.y - y)) <= 1:
            Piece.set_position(self, x, y)
        elif Piece.ifEat(self, x, y) and (max(abs(self.x - x), abs(self.y - y)) <= 1):
            Piece.set_position(self, x, y)
        elif Piece.ifEat(self, x, y) and (max(abs(self.x - x), abs(self.y - y)) <= 1):
            Piece.set_position(self, x, y)
        else:
            pygame.mixer.Sound.play(errorSound)
            turn = not turn


class Queen(Piece):
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def move(self, x, y):
        global turn
        if init_place[y][x] == "" and (Queen.ismove(self, x, y)):
            Piece.set_position(self, x, y)
        elif Piece.ifEat(self, x, y) and (Queen.ismove(self, x, y)):
            Piece.set_position(self, x, y)
        elif Piece.ifEat(self, x, y) and (Queen.ismove(self, x, y)):
            Piece.set_position(self, x, y)
        else:
            pygame.mixer.Sound.play(errorSound)
            turn = not turn

    def ismove(self, x, y):
        state = 1

        dx = x - self.x
        dy = y - self.y

        if abs(dx) == abs(dy):
            step_x = 1 if dx > 0 else -1
            step_y = 1 if dy > 0 else -1
            for i in range(1, abs(dx)):
                if init_place[self.y + i * step_y][self.x + i * step_x] != "":
                    state = 0
                    break

        elif dx == 0 or dy == 0:
            if dx == 0:
                step_y = 1 if dy > 0 else -1
                for i in range(1, abs(dy)):
                    if init_place[self.y + i * step_y][self.x] != "":
                        state = 0
                        break
            elif dy == 0:
                step_x = 1 if dx > 0 else -1
                for i in range(1, abs(dx)):
                    if init_place[self.y][self.x + i * step_x] != "":
                        state = 0
                        break

        return (self.x == x or self.y == y or abs(y - self.y) == abs(x - self.x)) and (
            state
        )


class Knight(Piece):
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def move(self, x, y):
        global turn
        if init_place[y][x] == "" and (Knight.ismove(self, x, y)):
            Piece.set_position(self, x, y)
        elif Piece.ifEat(self, x, y) and (Knight.ismove(self, x, y)):
            Piece.set_position(self, x, y)
        elif Piece.ifEat(self, x, y) and (Knight.ismove(self, x, y)):
            Piece.set_position(self, x, y)
        else:
            pygame.mixer.Sound.play(errorSound)
            turn = not turn

    def ismove(self, x, y):
        return (
            abs(self.x - x) == 2
            and abs(self.y - y) == 1
            or abs(self.x - x) == 1
            and abs(self.y - y) == 2
        )


class Rook(Piece):
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def move(self, x, y):
        global turn
        if (
            init_place[y][x] == ""
            and (self.x == x or self.y == y)
            and Rook.ismove(self, x, y)
        ):
            Piece.set_position(self, x, y)
        elif (
            Piece.ifEat(self, x, y)
            and (self.x == x or self.y == y)
            and Rook.ismove(self, x, y)
        ):
            Piece.set_position(self, x, y)
        elif (
            Piece.ifEat(self, x, y)
            and (self.x == x or self.y == y)
            and Rook.ismove(self, x, y)
        ):
            Piece.set_position(self, x, y)
        else:
            pygame.mixer.Sound.play(errorSound)
            turn = not turn

    def ismove(self, x, y):
        # Initialize state as clear
        state = 1

        if x == self.x:  # Vertical movement
            step = 1 if y > self.y else -1
            for i in range(self.y + step, y, step):
                if init_place[i][x] != "":
                    state = 0
                    break

        elif y == self.y:  # Horizontal movement
            step = 1 if x > self.x else -1
            for i in range(self.x + step, x, step):
                if init_place[y][i] != "":
                    state = 0
                    break

        return state


class bishop(Piece):
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def move(self, x, y):
        global turn
        if (
            init_place[y][x] == ""
            and abs(y - self.y) == abs(x - self.x)
            and bishop.ismove(self, x, y)
        ):
            Piece.set_position(self, x, y)
        elif (
            Piece.ifEat(self, x, y)
            and (abs(y - self.y) == abs(x - self.x))
            and bishop.ismove(self, x, y)
        ):
            Piece.set_position(self, x, y)
        elif (
            Piece.ifEat(self, x, y)
            and (abs(y - self.y) == abs(x - self.x))
            and bishop.ismove(self, x, y)
        ):
            Piece.set_position(self, x, y)
        else:
            pygame.mixer.Sound.play(errorSound)
            turn = not turn

    def ismove(self, x, y):
        state = 1
        step_x = 1 if x - self.x > 0 else -1
        step_y = 1 if y - self.y > 0 else -1

        # Check each square along the diagonal path
        for i in range(1, abs(x - self.x)):
            if init_place[self.y + i * step_y][self.x + i * step_x] != "":
                state = 0
                break
        return state


def load_images():
    images = {}
    for piece_name in pi.keys():
        image = pygame.image.load(f"img\\{piece_name}.png").convert_alpha()
        images[piece_name] = pygame.transform.scale(image, (100, 100))
    return images


def handle_click(pos):
    global d, origin, destination, press
    for area, label in clickable_areas:
        if area[0] <= pos[0] < area[2] and area[1] <= pos[1] < area[3]:
            print(event.pos)
            x, y = moves[label]
            if d == 0 and init_place[y][x] != "":
                origin = label
                d = 1
            elif d == 1:
                destination = label
                press = True
                d = 0
            break


def draw_board(screen, colors):
    color = 0
    for row in players:
        for square in row:
            pygame.draw.rect(screen, colors[color], square)
            color = 1 - color
        color = 1 - color


def draw_pieces(screen):
    for y, row in enumerate(init_place):
        for x, piece in enumerate(row):
            if piece:
                screen.blit(images[piece], (x * 100, y * 100))


# Initialization
d = 0
turn = 0
once = 8
origin = ""
destination = ""
press = False
screen_width = 800
screen_height = 800
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Chess Game")
moveSound = pygame.mixer.Sound(r"sound\move-self.mp3")
captureSound = pygame.mixer.Sound(r"sound\capture.mp3")
startSound = pygame.mixer.Sound(r"sound\game-start.mp3")
errorSound = pygame.mixer.Sound(r"sound\incorrect.mp3")
# Precompute rectangles for each square
players = [
    [pygame.Rect(x * 100, y * 100, 100, 100) for x in range(8)] for y in range(8)
]

# Load piece images
images = load_images()
# start sound
# Game loop
colors = [(255, 255, 255), (0, 0, 0)]
run = True
while run:
    screen.fill((0, 0, 0))
    draw_board(screen, colors)
    draw_pieces(screen)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            handle_click(event.pos)
    if press:
        origin_x, origin_y = moves[origin]
        Piece.move_manager(init_place[origin_y][origin_x], origin, destination)
        # pygame.mixer.Sound.play(moveSound)
        press = False
        time.sleep(0.5)
        # piece.ifKing() For king cant move and in checkmate (call who win and rest the bord after 1 sec)
    # start sound
    if once:
        pygame.mixer.Sound.play(startSound)
        once = 0
    pygame.display.update()

pygame.quit()
